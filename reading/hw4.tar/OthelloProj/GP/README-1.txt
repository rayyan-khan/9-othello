
In order to install the Genetic Programming package into you
directory, you must copy all of the files into a directory in
your account from the directory "/u/niform/eeskin/TA/dist/GP/"

You must also copy all of the sub directories to this directory so you
must use the "-R" flag to copy everything.

This will give you a copy of the genetic programming package.  Note
there are several sub directories within the package.  "gpjpp"
contains the source files.  "docs" contains the javadoc documenation
for the source files.  The other directories corespond to example
applications.

In order to compile the GP package, you must first include the
compiler in your path.  To do this add to your path on the cs cluster:

"/opt/SUNWJava/JDK-1.1.3/bin"

In order for java to find the relevent source files, add the following
paths to your CLASSPATH variable:

"/opt/SUNWJava/JDK-1.1.3/lib/classes.zip"
"{your_path}/GP"

later you will also add:

"{your_path}/othello/"


Now that you have set these variables, it is time to compile.
Enter the directory "GP/gpjpp" and type "javac *.java"
This should take a while but you should recieve no errors.

Then enter the directory "GP/SymbReg" and type "javac *.java"
Now the Symbolic Representation Package should be running.  In order
to execute it, you must type:

"java SymbReg"

This should be all you need to get the GP implementation up and
running in your directory.

There are several files in the SymbReg directory that are of interest.
The SymbReg.java is the source file where the Sybolic Regression is
defined.  Note this is the ONLY source file that has to do with
Symbolic regression.  Othello will have a very similar file to
interface with the GP pakage.

There is also a file called SymbReg.ini .  This file has a lot of
parameters for the GP.  A complete set of possible parameters are
contained the in documentation for the GPVariables class.  Note you can
tweak these parameters pretty easily to experiment with the GP.

There is also a file that is called SymbReg.stc that gives statistics
on a run of the program.  A file called SymbReg.det can be created if
you set the PrintDetails option to true in the SymbReg.ini file.  This
will give you plenty of details for each generation including best
and worst individual.

After a run is over, a gif file of the tree of the best individual is
created.  Note, to keep the GP from crashing you must set an
appropriate DISPLAY variable.

Note also that the documentation is in html.
