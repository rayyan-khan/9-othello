// The OthelloCache handles the cache file of board states and moves
// in order to allow fast training.  The relevant board statistics of a move
// are stored along with edgars value for each available move.


import java.io.*;
import java.util.*;

public class OthelloCache 
{


  OthelloBoard board;
  OthelloPlayer whitePlayer;
  OthelloPlayer blackPlayer;
  DataOutputStream outputStream;

  boolean scoreOnly;


  // Handles commandling arguments.

  public static void main(String argv[]) {

    boolean noDisplay=false;

    String player = "";
    boolean whoplays = false;

    if (argv.length>0) {
      for (int i=0; i<argv.length; i++) {
	if (argv[i].equals("scoreonly"))
	  noDisplay = true;
	else {
	  player = argv[i];
	  whoplays = true;
	}
      }
    }
    

    OthelloCache cache;

    // if we are not displaying, we play fifty games and only show the score.
    if (noDisplay == true) {

      for (int i=0; i<50; i++) {
	cache = new OthelloCache(noDisplay,whoplays, player);
      }
    } else
    cache = new OthelloCache(noDisplay,whoplays, player); 
 
  }


  OthelloCache(boolean noDisplay, boolean whoplays, String function) {

    try {


      // This file is opened which at one point in this implementation contained
      // possible moves and their rankings.  It is left here so you can see how to
      // "cache" training cases for faster training.

      FileOutputStream oStream = new FileOutputStream("traindata");
      outputStream = new DataOutputStream(oStream);


      board = new OthelloBoard();
      
      scoreOnly=noDisplay;

      if (whoplays)
	whitePlayer = new OthelloGPPlayer(OthelloBoard.WHITE,function);
      else
	whitePlayer = new OthelloEdgar();
      blackPlayer = new OthelloRandomPlayer(OthelloBoard.BLACK);

      playGame();
    
      outputStream.close();
    } catch(Exception e) {
      System.out.println("Error in writing file");
    }
  }


  // This handles the actual game playing.
  public void playGame() throws IOException{

    // Training data.
    OthelloBoard tempBoard;
    Vector rankedMoves;
    Move trainingMove;
    String output;

    Move currentMove;
      
    while(!board.gameOver()) {
	
      if (board.gameTurn==OthelloBoard.BLACK) {
	
	currentMove = blackPlayer.bestMove(board);
	board.makeMove(OthelloBoard.BLACK, currentMove.col(), currentMove.row());
	if (!scoreOnly) {
	    System.out.println("Black Move: Col = " + currentMove.col() + "Row = " + currentMove.row());
	    board.PrintBoard();
	}


      } else {

	// Training caching was done here.
	// Now the program displays the information.  Usefull for debugging.
        
	rankedMoves = whitePlayer.rankMoves(board);
	for (int i =0; i< rankedMoves.size(); i++) {
	  tempBoard = board.copy();
	  trainingMove = (Move)rankedMoves.elementAt(i);
	  tempBoard.makeMove(OthelloBoard.WHITE, trainingMove.col(), trainingMove.row());

	  output = "" + (i+1) + " " + trainingMove.value() + " " + tempBoard.printBoardStatistics();

	  if (!scoreOnly)
	    System.out.println("" + trainingMove + output);
	  outputStream.writeBytes(output+"\n");
	}
	//outputStream.writeChars("\n");
	currentMove = whitePlayer.bestMove(board);

	board.makeMove(OthelloBoard.WHITE, currentMove.col(), currentMove.row());
	if (!scoreOnly) {
	    System.out.println("White Move: Col = " + currentMove.col() + "Row = " + currentMove.row());
	    board.PrintBoard();
	}
      }
    }
      if (board.gameOver())
	endGame();
  }

  public void endGame()
  {
    // Any end game stuff in here.

    String output;

    board.updateBoardStatistics();

    if (board.num_white < board.num_black) 
      output = "BLACK";
    else
      output = "WHITE";
    output = output + " wins.  The final score is WHITE " + board.num_white + " BLACK " + board.num_black + ".";
    
    System.out.println(output);
  }
    
}  
  

  
