

import java.io.*;
import java.util.*;

public class OthelloGPPlayer extends OthelloPlayer
{

        String function;


	OthelloGPPlayer(int color, String definition)
	{
	  super(color);

	  function = definition;

	}
	



  public double evalFunction(double white,
			     double black,
			     double white_edges,
			     double black_edges,
			     double white_corners,
			     double black_corners,
			     double white_near_corners,
			     double black_near_corners) {

    StringTokenizer stok = new StringTokenizer(function);

    return evalSubFunction(stok,white,black,white_edges,black_edges,
			   white_corners,black_corners, white_near_corners, black_near_corners);

  }

  public double  evalSubFunction(StringTokenizer stok, 
				 double white,
				 double black,
				 double white_edges,
				 double black_edges,
				 double white_corners,
				 double black_corners,
				 double white_near_corners,
				 double black_near_corners) { 
    String item;



      item = stok.nextToken();

      if (item.equals("("))
	item = stok.nextToken();
      if (item.equals(")"))
	item = stok.nextToken();
      if (item.equals("))"))
	item = stok.nextToken();
      if (item.equals(")))"))
	item = stok.nextToken();
      if (item.equals("))))"))
	item = stok.nextToken();
      if (item.equals("+")) {
	return evalSubFunction(stok,white,black,
			       white_edges,black_edges,
			       white_corners, black_corners,
			       white_near_corners, black_near_corners) + 
	  evalSubFunction(stok,white,black,white_edges,black_edges,
			  white_corners,black_corners, white_near_corners, black_near_corners);
      }
      if (item.equals("-")) {
	return evalSubFunction(stok,white,black,
			       white_edges,black_edges,
			       white_corners, black_corners,
			       white_near_corners, black_near_corners) - 
	  evalSubFunction(stok,white,black,white_edges,black_edges,
			  white_corners,black_corners,
			  white_near_corners, black_near_corners);
      }
      if (item.equals("*")) {
	return evalSubFunction(stok,white,black,
			       white_edges,black_edges,
			       white_corners, black_corners,
			       white_near_corners, black_near_corners) * 
	  evalSubFunction(stok,white,black,white_edges,black_edges,
			  white_corners,black_corners,
			  white_near_corners, black_near_corners);
      }
      if (item.equals("/")) {
	return divide(evalSubFunction(stok,white,black,
				      white_edges,black_edges,
				      white_corners, black_corners,
				      white_near_corners, black_near_corners), 
	  evalSubFunction(stok,white,black,white_edges,black_edges,
			  white_corners,black_corners,
			  white_near_corners, black_near_corners));
      }
      if (item.equals("white")) {
	return white;
      }
      if (item.equals("black")) {
	return black;
      }
      if (item.equals("white_edges")) {
	return white_edges;
      }
      if (item.equals("black_edges")) {
	return black_edges;
      }
      if (item.equals("white_corners")) {
	return white_corners;
      }
      if (item.equals("black_corners")) {
	return black_corners;
      }
      if (item.equals("white_near_corners")) {
	return white_near_corners;
      }
      if (item.equals("black_near_corners")) {
	return black_near_corners;
      }
      if (item.equals("10")) {
	return 10.0;
      }

    System.out.println("Parse Error");
    return 0.0;
  }

        // This method gets over written with the evaluation function of players.
        public double evalMove(OthelloBoard board, Move move) {
	  
	  OthelloBoard tempBoard = board.copy();

	  tempBoard.makeMove(color, move.col(), move.row());

	  tempBoard.updateBoardStatistics();

	  
	  
	  //double result = ((double)tempBoard.num_white_edges - (double)tempBoard.num_black) *
	  //	     ((double)tempBoard.num_black - 10);


	  //double result = ((double)tempBoard.num_white - (double)tempBoard.num_black);

	  //   double result = divide((double)tempBoard.num_white,
	  //			    divide((double)tempBoard.num_white_edges-(double)tempBoard.num_black, (double)tempBoard.num_black));

	     //	  System.out.println("Result = " + result);
	    
	double result = evalFunction((double)tempBoard.num_white,
				     (double)tempBoard.num_black,
				     (double)tempBoard.num_white_edges,
				     (double)tempBoard.num_black_edges,
				     (double)tempBoard.num_white_corners,
				     (double)tempBoard.num_black_corners,
				     (double)tempBoard.num_white_near_corners,
				     (double)tempBoard.num_black_near_corners);

	  return result;
	}


        public double divide(double x, double y) {
    
	  if (y==0) {
	    return x;
	  } else {
	    return x/y;
	  }
	}
}
