

import java.io.*;
import java.util.*;

public class OthelloRandomPlayer extends OthelloPlayer
{



	OthelloRandomPlayer(int color)
	{

	  super(color);

	}
	


        // This method gets over written with the evaluation function of players.
        public double evalMove(OthelloBoard board, Move move) {
	  

	  Random random = new Random();

	  double result = random.nextDouble();

	  return result;
	}


}
