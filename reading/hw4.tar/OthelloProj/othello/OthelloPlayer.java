

import java.io.*;
import java.util.*;

public class OthelloPlayer
{


        int color;


	OthelloPlayer(int color)
	{

	  this.color = color;

	}
	


        // This method gets over written with the evaluation function of players.
        public double evalMove(OthelloBoard board, Move move) {
	  

	  return 0.0;
	}

        public Vector rankMoves(OthelloBoard board) {

	  Vector possibleMoves = board.possibleMoves(color);
	  int value;
	  Move move;

	  for (int i=0; i< possibleMoves.size(); i++) {
	    move = (Move)possibleMoves.elementAt(i);
	    move.setValue(evalMove(board, move));
	    possibleMoves.setElementAt(move,i);
	  }


	  // Very innefficient bubble sort, but it is short and easy. :)
	  Move tempMove;
	  for (int j=0; j< possibleMoves.size()-1; j++) {
	    for (int k=0; k< possibleMoves.size()-1; k++) {
	      if (((Move)possibleMoves.elementAt(k)).value() > ((Move)possibleMoves.elementAt(k+1)).value()) {
		tempMove = (Move)possibleMoves.elementAt(k+1);
		possibleMoves.setElementAt(possibleMoves.elementAt(k),k+1);
		possibleMoves.setElementAt(tempMove,k);
	      }
	    }
	  }
	      

	  return possibleMoves;
	}
	    
        public Move bestMove(OthelloBoard board) {
	  

	  Vector rankedMoves = rankMoves(board);
	  Move bestMove = (Move)rankedMoves.elementAt(0);  
	  Move thisMove;

	  for (int i=0; i<rankedMoves.size(); i++) {
	    thisMove = (Move)rankedMoves.elementAt(i);
	    if (bestMove.value() < thisMove.value()) {
	      bestMove=thisMove;
	    }
	  }
	  return bestMove;
	}

	
}
