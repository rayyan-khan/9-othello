

import java.applet.*;
import java.awt.*;
import java.awt.image.*;
import java.net.*;
import java.io.*;

public class OthelloEdgar extends OthelloPlayer
{

        static final int WHITE = 1;

	// This is the "learning" that was done and will be used
        // to decide what to do in a particular situation
        double DecisionsValue[][][] = new double[60][8][8];
        double DecisionsValueNumber[][][] = new double[60][8][8];
        double DecisionsValueWeight[][][] = new double[60][8][8];
        double DecisionsFlipWeight[][][] = new double[60][8][8];

        int CornerPenalty;


	OthelloEdgar()
	{

	  super(WHITE);



		//		if (FirstTime)
		//{
		/* ------------- Read in FinalWeights ---------------- */
		    try {
		      //URL myURL = new URL(getDocumentBase(),"FinalWeights");
		FileInputStream myStream = new FileInputStream("FinalWeights");
		StreamTokenizer myTok = new StreamTokenizer(myStream);
		
		myTok.parseNumbers();

		int counter = 0;
		do 
		  {
		      myTok.nextToken();
		      if (myTok.ttype == myTok.TT_NUMBER) 
			{
			  double thisNum = myTok.nval;
			  switch (counter % 5)
			    {
			      case 0:
				break;
			      case 1:
				DecisionsValue[counter/(8*8*5)]
                                         [(counter/(5*8)) % 8]
                                         [(counter/5) % 8] = thisNum;
				break;
			      case 2:
				DecisionsValueNumber[counter/(8*8*5)]
                                         [(counter/(5*8)) % 8]
                                         [(counter/5) % 8] = thisNum;
				break;
			      case 3:
				DecisionsValueWeight[counter/(8*8*5)]
                                         [(counter/(5*8)) % 8]
                                         [(counter/5) % 8] = thisNum;
				break;
			      case 4:
				DecisionsFlipWeight[counter/(8*8*5)]
                                         [(counter/(5*8)) % 8]
                                         [(counter/5) % 8] = thisNum;
				break;
			    }
			  counter++;
			}
		      else 
			{
			    System.out.println("Read a string: " + myTok.sval +
					       "at counter " + counter);
			}
		  }
		while (myTok.ttype != myTok.TT_EOF);
		} catch (Exception e)
                 {System.out.println("An Error Occured Reading the data file.");}
		 
		/* ------------- Print out FinalWeights ---------------- */

		    CornerPenalty = ((int) DecisionsValue[0][0][0]);
				/* System.out.println("Corner Penalty is " + CornerPenalty); */
	}
	
	


        public double evalMove(OthelloBoard board, Move move) {
	  
	  return (double)rankLEARNEDMove(WHITE, move.col(), move.row(), board);
	}
 



	
  /*	public void doComputerMove()
	{

		boolean canMove = findComputerMove(COMPUTER);
	
		// if the USER has no move, COMPUTER keeps taking moves
		// until the USER has a move, or there is a game over
		
		while (!hasMove(USER) && !gameIsOver) {
			if (canMove) {
				// no USER move, COMPUTER takes another
				canMove = findComputerMove(COMPUTER);
			} else {
				// nothing else to do
				gameIsOver = true;
			}
		}
	
		//		if (!gameIsOver) {
		//	updateMessage("Your turn.");
		//} else {
		//	endGame();
		//}
	}*/


	/**
	 * do the best possible move
	 */
  /*	boolean findComputerMove(int color)
	{
		int best_count = 0, this_count,
			best_col = 0, best_row = 0;
		boolean NotYet = true;
		
		for (int col = 1; col < 9; col++) 
		    for (int row = 1; row < 9; row++) 
		      {
			  this_count = rankLEARNEDMove( color, col, row ); 
			  if (((best_count < this_count) || 
			       (NotYet)) && (this_count != 0))
			    {
				NotYet = false;
				best_col = col;
				best_row = row;
				best_count = this_count;
			    }
		      }

		if (best_count != 0)	{
		  //if (soundIsTurnedOn)
		  //	computerMoveSound.play();
			board.makeMove(color, best_col, best_row);
			return true;
		} else {
			return false;
		}
	}
	*/

	/* --------------------------------------------------*/
	boolean SetUpForCorner(int color, int col, int row, OthelloBoard board)
	  {
	      int scoretemp[] = new int[3];
	      int boardtemp[][] = new int[9][9];
	      int opponent = OthelloBoard.BLACK + OthelloBoard.WHITE - color;
	      boolean toreturn;

	      scoretemp[OthelloBoard.BLACK] = board.score[OthelloBoard.BLACK];
	      scoretemp[OthelloBoard.WHITE] = board.score[OthelloBoard.WHITE];

	      for(int i = 0;i<9;i++)
   	        for(int j = 0;j<9;j++)
                  boardtemp[i][j] = board.board[i][j];

	      board.FakemakeMove(color, col, row);

	      if ((board.isLegalMove(opponent,1,1)) ||
		  (board.isLegalMove(opponent,1,8)) ||
		  (board.isLegalMove(opponent,8,1)) ||
		  (board.isLegalMove(opponent,8,8)))
                 toreturn = true;
	      else
                 toreturn = false;

	      board.score[OthelloBoard.BLACK] = scoretemp[OthelloBoard.BLACK];
	      board.score[OthelloBoard.WHITE] = scoretemp[OthelloBoard.WHITE];

	      for(int i = 0;i<9;i++)
   	        for(int j = 0;j<9;j++)
                  board.board[i][j] = boardtemp[i][j];
	      
	      return toreturn;
	  }

	/* --------------------------------------------------*/
	int rankLEARNEDMove (int color, int col, int row, OthelloBoard board)
	  {
	      int count = 0;
	      int rowinc,colinc;
	      double Value;
	      double Flip;
	      
	      /* somebody's piece is already in this location */
		if ((board.board[col][row] != OthelloBoard.EMPTY) && (board.board[col][row] != OthelloBoard.OKMOVE))
                  return 0;
  
	      for (colinc = -1; colinc < 2; colinc++) 
		  for (rowinc = -1; rowinc < 2; rowinc++) 
		      count += board.flipRow(color, col, row, colinc, rowinc, false,
				       false);

	      if (count == 0) 
                  return count;

	      Flip  = 
                  ((double)count)*(DecisionsFlipWeight[board.GameTime][col-1][row-1]);

	      Value = (DecisionsValue[board.GameTime][col-1][row-1])*
                      (DecisionsValueWeight[board.GameTime][col-1][row-1]);

	      Value = (Value + Flip);
	      
	      if (SetUpForCorner(color,col,row, board))
	          count = ((int)(Value * 10)) - CornerPenalty;
	      else
	          count = ((int)(Value * 200.0));
	      
	      if (count == 0)
                  count = 1;
	      
	      //System.out.println("Game Time = " + board.GameTime + " Column = " + col + " Row = " + row + " Value = " + count); 

	      return count;
} 
	/* --------------------------------------------------*/


	/**
	 * score move based on number of pieces flipped
	 * the strategy in here is sad
	 */
	/*	int rankMove (int color, int col, int row)
	{
		int count = 0;
		*/
		// somebody's piece is already in this location
	/*		if ((board.board[col][row] != EMPTY) && (board.board[col][row] != OKMOVE)){
			return 0;
		}

		for (int colinc = -1; colinc < 2; colinc++) {
			for (int rowinc = -1; rowinc < 2; rowinc++) {
				count += board.flipRow(color, col, row, colinc, rowinc,
						 false, false);
			}
		}

		if (count > 0) 
                    {
			count++;
			*/                     // Prefer the edges
	/*        if (((col == 1) || (col == 8) || (row == 1) || 
			     (row == 8)))
			  {
			      count += 8;
			  }
			  */
			// Make the corners most desirable
	/*		if (((col == 1) || (col == 8)) && ((row == 1) || (row == 8))) {
				count = 64;
			}
			*/
		       // Make the squares next to the corner least desirable
	/*	if ((((col == 1) || (col == 8)) && ((row == 2) || (row == 7))) ||
	(((row == 1) || (row == 8)) && ((col == 2) || (col == 7))) ||
	(((col == 2) || (col == 7)) && ((row == 2) || (row == 7)))) {
				count = 1;
			}
		}
		return count;
	} 
	*/


}



