Othello README


I.  Setup and Execution

To set up Othello in your local directory, follow the same steps as in
setting up the GP and copy the Othello files into a subdirectory.  Add
the path to the Othello files in your CLASSPATH variable.

To compile Othello, type:

javac *.java

Note, you will recieve warnings.  Ignore them, they are just Java 1.0
vs Java 1.1 differences in the code.  They will not affect performance.


There are several programs that comprise the Othello package.

The first is the original Othello by Astro Teller.  To play Othello
against Edgar, Astro's AI, type:

appletviewer Othello.html

To watch a GP Player play against a Random player, type:

appletviewer OthelloDisplay.html

To Watch a non graphical game of Othello useful for debugging and
testing out players, type:

java OthelloCache

To have Othello play fifty games and tell you only the scores type:

java OthelloCache scoreonly

To have a user defined genetic player play against random players
type:

java OthelloCache "<genetic representation>"

or

java OthelloCache scoreonly "<genetic representation>"

where <genetic representation> is an expression in prefix form with
the operators:
"+,-,*,/"
and the terminals:
"white, black, white_edges, black_edges, white_corners, black_corners,
white_near_corners, black_near_corners, 10"

To have the GP train players, type:

java GPOthello basename

The basename parameter is optional.  The results will be stored in
files with the basename parameter as the file stem.

Make sure you set your DISPLAY variable before running GPOthello since
it requires graphical capabilities when it draws the best individual.

---------------------------------------------------------------------


II. Description of Source Files.

OthelloBoard.java - this class handles creating and updating the
board.  This file also keeps track of board statistics and possible
moves.  All game related functions are handled in this class.

OthelloPlayer.java - this class is the superclass for all Othello
Players.  An Othello player ranks each move based on the current board
position.  This player ranks each move with value 0.0.  Other players
overwrite this ranking with a more reasonable value.  Because this
player ranks all moves the same, the player always picks the first
move.

OthelloEdgar.java - this is Astro's AI.  As a player, expect Edgar to
kick your players butts.  This player can be used for training once
our players get good enough.  Note: Edgar was trained to play white.

OthelloRandomPlayer.java - this player picks random moves.

OthelloGPPlayer.java - this player plays lets us pass as the
parameter, the representation of a genetic player.  This allows us to
test players.

OthelloGPTester.java - this player is essentially the OthelloGPPlayer,
but optimized so that it can run using the GP data structure so that
it is faster to train with.  Examine the code to see how it is used.
It actually calls the evaluate function of the GP directly.

GPOthello.java - this file defines all of the classes for the GP
training implementation of Othello.  Note that this file is vary
similar to the Symbolic Regression file.  Examine to code to see how
the players get evaluated.  You will probably change this to suit your
needs.

OthelloCache.java - this file defines the non graphical game playing.
Use this to test your players, it is much faster than watching the
graphical interface.  Also, this creates a training file which you may
want to use for training.

OthelloDisplay.java - graphical interface for showing off your players.

Othello.java - original Othello by Astro Teller.  NOTE: This file is
NOT compatible with the rest of the file.  I included it so you can
examine the code to see how the user interface works.
