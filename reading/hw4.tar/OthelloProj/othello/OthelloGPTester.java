

import java.io.*;
import java.util.*;



public class OthelloGPTester extends OthelloPlayer
{

        String function;
        GPOthelloGP gp;
  //Method eval;

	OthelloGPTester(int color, GPOthelloGP gp)
	{
	  super(color);

	  this.gp = gp;
	  // this.gp = gp.getClass();
	  //eval = gp.getMethod("get", new Class[] { int.class });
	}
	

        public double evalFunction(double white, 
				   double black, 
				   double white_edges,
				   double black_edges,
				   double white_corners,
				   double black_corners,
				   double white_near_corners,
				   double black_near_corners) {
	  //Object args[] = { new Integer(0) };
	  //GPOthelloGene gene = (GPOthelloGene)gp.invoke(eval,args);

	return  ((GPOthelloGene)gp.get(0)).evaluate(white, 
						    black,
						    white_edges,
						    black_edges,
						    white_corners,
						    black_corners,
						    white_near_corners,
						    black_near_corners,
						    gp, 0, 0);
	}

        // This method gets over written with the evaluation function of players.

        public double evalMove(OthelloBoard board, Move move) {
	  
	  OthelloBoard tempBoard = board.copy();

	  tempBoard.makeMove(color, move.col(), move.row());

	  tempBoard.updateBoardStatistics();

	  
	  
	  //double result = ((double)tempBoard.num_white_edges - (double)tempBoard.num_black) *
	  //	     ((double)tempBoard.num_black - 10);


	  //double result = ((double)tempBoard.num_white - (double)tempBoard.num_black);

	  //   double result = divide((double)tempBoard.num_white,
	  //			    divide((double)tempBoard.num_white_edges-(double)tempBoard.num_black, (double)tempBoard.num_black));

	     //	  System.out.println("Result = " + result);
	    
	double result = evalFunction((double)tempBoard.num_white,
				     (double)tempBoard.num_black,
				     (double)tempBoard.num_white_edges,
				     (double)tempBoard.num_black_edges,
				     (double)tempBoard.num_white_corners,
				     (double)tempBoard.num_black_corners,
				     (double)tempBoard.num_white_near_corners,
				     (double)tempBoard.num_black_near_corners);

	  return result;
	}


        public double divide(double x, double y) {
    
	  if (y==0) {
	    return x;
	  } else {
	    return x/y;
	  }
	}
}
