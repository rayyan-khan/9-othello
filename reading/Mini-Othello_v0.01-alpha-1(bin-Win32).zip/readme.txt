It is in C/C++, so no flashy graphics, sorry.

To run, open a console window (DOS window), go to the directory where the .exe file is located. Type the "othello" to play a game of default settings. Type "othello --help" for options available.

Have fun!
